<?php
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "qlsv";

    //Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    //Check connection
    if($conn->connect_error){
        die("Connection failed: " . $conn->connect_error);
    }

    //Tao chuoi luu cau lenh sql
    $sql = "SELECT *FROM student";

    if($result = $conn->query($sql)){
        while ($row = $result -> fetch_row()) {
            printf ("%s | %s | %s |  %d \n", $row[0], $row[1],$row[2],$row[3]);
            echo "<br>";
          }
        $result -> free_result();
    }
    $conn->close();
?>