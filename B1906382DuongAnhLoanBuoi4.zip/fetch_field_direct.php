<?php
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "qlsv";

    //Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    //Check connection
    if($conn->connect_error){
        die("Connection failed: " . $conn->connect_error);
    }

    //Tao chuoi luu cau lenh sql
    $sql = "SELECT *FROM student";

    if($result = $conn->query($sql)){
        $fieldinfo = $result->fetch_field_direct(2);
            printf("Name: %s\n", $fieldinfo -> name);
            printf("Table: %s\n", $fieldinfo -> table);
            printf("Max. Len: %d\n", $fieldinfo -> max_length);
            echo "<br>";
        
        
        $result -> free_result();
    }
    $conn->close();
?>