<?php
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "qlsv";

    //Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    //Check connection
    if($conn->connect_error){
        die("Connection failed: " . $conn->connect_error);
    }

    //Tao chuoi luu cau lenh sql
    $sql = "SELECT *FROM student";

    if($result = $conn->query($sql)){
        $row = $result -> fetch_row();
  // Display field lengths
  foreach ($result -> lengths as $i => $val) {
    printf("Field %2d has length: %2d\n", $i + 1, $val);
            echo "<br>";
        }
        $result -> free_result();
    }
    $conn->close();
?>