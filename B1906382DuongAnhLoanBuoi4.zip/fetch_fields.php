<?php
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "qlsv";

    //Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    //Check connection
    if($conn->connect_error){
        die("Connection failed: " . $conn->connect_error);
    }

    //Tao chuoi luu cau lenh sql
    $sql = "SELECT *FROM student";

    if($result = $conn->query($sql)){
        $fieldinfo = $result->fetch_fields();
        foreach($fieldinfo as $val){
            printf("Name: %s\n", $val -> name);
            printf("Table: %s\n", $val -> table);
            printf("Max. Len: %d\n", $val -> max_length);
            echo "<br>";
        }
        $result -> free_result();
    }
    $conn->close();
?>