<?php
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "qlsv";

    //Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    //Check connection
    if($conn->connect_error){
        die("Connection failed: " . $conn->connect_error);
    }

    //Tao chuoi luu cau lenh sql
    $sql = "SELECT *FROM student";

    if ($result = $conn -> query($sql)) {
        while ($obj = $result -> fetch_object()) {
          printf("ID:%s -Fullname:%s- Email:%s- Ngay sinh:%s\n",
           $obj->id,$obj->fullname, $obj->email, $obj->Birthday);
            echo "<br>";
        }
        
        $result -> free_result();
    }
    $conn->close();
?>


