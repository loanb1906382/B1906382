<!DOCTYPE HTML>
<html>  
<body>

<form action="major_add_save.php" method="post">
ID :  <input type="text" name="id"><br>
Name major: <input type="text" name="name_major"><br>



<input type="submit">
</form>

</body>
</html>

