
<?php session_start(); 
 session_destroy(); 
 
//if (isset($_SESSION['user'])){
   // unset($_SESSION['user']); // xóa session login
//}
?>
<a href="homepage.php">HOME</a>

