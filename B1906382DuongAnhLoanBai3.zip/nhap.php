<!DOCTYPE HTML>
<html>  
<body>

<form action="welcome.php" method="post">
Name: <input type="text" name="name"><br>
E-mail: <input type="text" name="email"><br>
Pass: <input type="password" name="pss"> <br>
Date: <input type="date" name="date"><br>
<input type="submit">
</form>

</body>
</html>
