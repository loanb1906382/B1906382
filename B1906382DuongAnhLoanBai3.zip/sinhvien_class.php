<?php 

//khai bao lop sinh vien
class Sinhvien {
    public $mssv;
    public $hoten;
    public $date;

    // Methods, phuong thuc trong lop

    //phuong thuc xay dung
    function construct ($mssv, $hoten, $date){
        $this->mssv =$mssv;
        $this->hoten = $hoten;
        $this->date = $date;
    }

    //phuong thuc gan gia tri
    function set_sv ($mssv, $hoten, $date){
        $this->mssv = $mssv;
        $this->hoten = $hoten;
        $this->date = $date;
    }

    //phuong thuc huy
    function destruct($mssv, $hoten, $date){
        echo "MSSV {$this->mssv}";
        echo "Ho Ten {$this->hoten}";
        echo "Ngay sinh {$this->date}";

    }

    //phuong thuc tra ve gia tri

    function get_sv () {
        return "Ma so sinh vien: $this->mssv <br>
        Ho ten : $this->hoten <br>
        Ngay sinh: $this->date";
    }

    // Ham tinh tuoi
    function getAge (){
        date_default_timezone_set ('Asia/Ho_Chi_Minh');
        $birth = '2001-10-02';
        $diff= date_diff(date_create(), date_create($birth));
        $age= $diff->format ('%Y');
        echo " <br> Tuoi cua ban la: " .$age;
        
    }
}

// khoi tao bien kieu class Fruit() voi ham xay dung
$sv1 = new Sinhvien();

// cach goi phuong thuc da dinh nghia trong lop
$sv1->set_sv('B1906382',"Duong Anh Loan", "02/10/2001" );




//hien thi cac gia tri thong qua cac phuong thuc da dinh nghia
echo $sv1->get_sv() ;
echo $sv1->getAge();




?>




