<html>
<body>

Hello <?php echo $_POST["name"]; ?><br>
Your email address is: <?php echo $_POST["email"]; ?> 
<br>
Pass Word is: <?php echo $_POST ["pss"]; ?>
<br>
Date: <?php echo $_POST ["date"]; ?>

</body>
</html>
