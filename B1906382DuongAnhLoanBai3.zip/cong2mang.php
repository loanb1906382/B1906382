<!DOCTYPE html>
<html>
<body>

<?php
  $a= array(344,224,223,7737,9922,-828);
  $b = array(-344,-324,123,773,-9922,828);
  $c= array();

?>

</body>
</html>
